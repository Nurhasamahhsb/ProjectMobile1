package uas.com;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TambahData extends Activity {

	protected Cursor cursor ;
	DataHelper dbHelper;
	Button btnSave, btnCancel;
	EditText edtNirm, edtNama,edtMatakuliah, edtNilai;
	 
		public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tambah_data);
		
		dbHelper = new DataHelper(this);
		
		edtNirm =(EditText) findViewById(R.id.edtNirm);
		edtNama =(EditText) findViewById(R.id.edtNama);
	    edtMatakuliah =(EditText) findViewById(R.id.edtMatakuliah);
		edtNilai=(EditText) findViewById(R.id.edtNilai);
		btnSave =(Button) findViewById(R.id.btnSave);
		btnCancel =(Button) findViewById(R.id.btnCancel);

		btnSave.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				SQLiteDatabase db =dbHelper.getWritableDatabase();
				String sql = "INSERT INTO nilai VALUES('"
						+ edtNirm.getText().toString()
						+ "','"
						+ edtNama.getText().toString()
						+ "','"
						+ edtMatakuliah.getText().toString()
						+ "','"
						+ edtNilai.getText().toString() + "')";
				db.execSQL(sql);
				Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_LONG).show();
				MainActivity.ma.RefreshList();
				finish();		
			}
		}) ;
		btnCancel.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				finish();
			}
		});
	}	
}
