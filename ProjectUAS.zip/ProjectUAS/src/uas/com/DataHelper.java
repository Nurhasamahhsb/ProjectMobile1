package uas.com;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataHelper extends SQLiteOpenHelper {
	
	private static final String PROJECTUAS_NAME = "nilai.db";
	private static final int PROJECTUAS_VERSION = 1;
	
	public DataHelper(Context context){
		super(context, PROJECTUAS_NAME, null, PROJECTUAS_VERSION);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		String sql = "CREATE TABLE nilai(nirm integer primary key, "
				+ "nama text null, matakuliah text null, nilai text null);";
		Log.d("Data", "onCreate: " + sql);
		db.execSQL(sql);
		
		sql = "INSERT INTO nilai(nirm, nama, matakuliah, nilai) VALUES ('2018020794', "
				+ "'Nurhasamah Hasibuan', 'Pemrograman Mobile I', '80');";
		db.execSQL(sql);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		// TODO Auto-generated method stub

	}

}
