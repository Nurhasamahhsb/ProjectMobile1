package uas.com;

import uas.com.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends Activity {
    
	String[] daftar;
	ListView lvData;
	Cursor cursor;
	DataHelper dbCenter;
	public static MainActivity ma;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Button btnTambah = (Button) findViewById(R.id.button1);
        btnTambah.setOnClickListener(new View.OnClickListener(){

			public void onClick(View arg0) {
				Intent inten = new Intent(MainActivity.this, TambahData.class);
				startActivity(inten);
				
			}
        });
        
        ma = this;
        dbCenter = new DataHelper(this);
        RefreshList();
    }

	public void RefreshList() {
		SQLiteDatabase db = dbCenter.getReadableDatabase();
		cursor = db.rawQuery("SELECT * FROM nilai", null);
		daftar = new String[cursor.getCount()];
		cursor.moveToFirst();
		
		for (int i = 0; i<cursor.getCount(); i++){
			cursor.moveToPosition(i);
			daftar[i] = cursor.getString(1).toString();
		}
		
		lvData = (ListView) findViewById(R.id.listView1);
		lvData.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, daftar));
		
		lvData.setSelected(true);
		lvData.setOnItemClickListener(new OnItemClickListener(){

			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				
				final String selection = daftar[arg2];
				final CharSequence[]dialogitem = {"Ubah Data", "Hapus Data"};
				
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Pilihan");
				builder.setItems(dialogitem, new DialogInterface.OnClickListener(){

					public void onClick(DialogInterface dialog, int item) {
						switch (item){
						case 0:
							Intent inten =  new Intent(getApplicationContext(), UbahData.class);
							inten.putExtra("nama", selection);
							startActivity(inten);
							break;
						case 1:
							SQLiteDatabase db = dbCenter.getWritableDatabase();
							db.execSQL("delete from nilai where nama = '" + selection + "'");
							RefreshList();
							break;
						}	
					}
				});
				
				builder.create().show();
			}
		});
	}
}
