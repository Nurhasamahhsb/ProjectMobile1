package db.com;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LihatData extends Activity {

	protected Cursor cursor ;
	DataHelper dbHelper;
	Button btnBack;
	TextView tvNirm, tvNama,tvTgl, tvJk , tvJurusan;
	 
		public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.lihat_data);
		
		dbHelper = new DataHelper(this);
		
		tvNirm =(TextView) findViewById(R.id.tvNirm);
		tvNama =(TextView) findViewById(R.id.tvNama);
		tvTgl =(TextView) findViewById(R.id.tvTgl);
		tvJk =(TextView) findViewById(R.id.tvJk);
		tvJurusan =(TextView) findViewById(R.id.tvJurusan);

		SQLiteDatabase db = dbHelper.getReadableDatabase();
		cursor = db.rawQuery("SELECT * FROM mahasiswa WHERE nama = '"
				+ getIntent().getStringExtra("nama")+ "'", null);
		cursor.moveToFirst();
		
		if (cursor.getCount()>0){
			cursor.moveToPosition(0);
			tvNirm.setText(cursor.getString(0).toString());
			tvNama.setText(cursor.getString(1).toString());
			tvTgl.setText(cursor.getString(2).toString());
			tvJk.setText(cursor.getString(3).toString());
			tvJurusan.setText(cursor.getString(4).toString());
		}
		
		btnBack = (Button) findViewById(R.id.btnBack);
		btnBack.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				finish();
			}
		});			
	}
}
