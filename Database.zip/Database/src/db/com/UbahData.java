package db.com;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UbahData extends Activity {

	protected Cursor cursor ;
	
	DataHelper dbHelper;
	Button btnSave, btnCancel;
	EditText edtNirm, edtNama, edtTgl, edtJk , edtJurusan;
	 
		public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ubah_data);
		
		dbHelper = new DataHelper(this);
		
		edtNirm =(EditText) findViewById(R.id.edtNirm);
		edtNama =(EditText) findViewById(R.id.edtNama);
		edtTgl =(EditText) findViewById(R.id.edtTgl);
		edtJk =(EditText) findViewById(R.id.edtJk);
		edtJurusan =(EditText) findViewById(R.id.edtJurusan);

		SQLiteDatabase db = dbHelper.getReadableDatabase();
		cursor = db.rawQuery("SELECT * FROM mahasiswa WHERE nama = '"
				+ getIntent().getStringExtra("nama")+ "'", null);
		cursor.moveToFirst();
		
		if (cursor.getCount()>0){
			cursor.moveToPosition(0);
			edtNirm.setText(cursor.getString(0).toString());
			edtNama.setText(cursor.getString(1).toString());
			edtTgl.setText(cursor.getString(2).toString());
			edtJk.setText(cursor.getString(3).toString());
			edtJurusan.setText(cursor.getString(4).toString());
		}
		
		btnSave = (Button) findViewById(R.id.btnSave);
		btnCancel = (Button) findViewById(R.id.btnCancel);
		
		btnSave.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View arg0) {
				SQLiteDatabase db =  dbHelper.getWritableDatabase();
				db.execSQL("update mahasiswa set nama='"
						+ edtNama.getText().toString() + "', tgl='"
						+ edtTgl.getText().toString() + "', jk='"
						+ edtJk.getText().toString() + "', jurusan='"
						+ edtJurusan.getText().toString() + "' where nirm='"
						+ edtNirm.getText().toString() + "'");
				Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_LONG).show();
				MainActivity.ma.RefreshList();
				finish();
			}
		});	
		
		btnCancel.setOnClickListener(new View.OnClickListener(){

			public void onClick(View arg0) {
				finish();
			}
		});
	}
}
